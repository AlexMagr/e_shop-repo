<?
//$_COOKIE['visitCounter']=null;
(int)$visitCounter=0;
if(isset($_COOKIE['visitCounter'])){
	$visitCounter=$_COOKIE['visitCounter'];
}//else{echo 'Cookie с именем visitCounter нету:)';}
$visitCounter++;
$lastVisit="";
if(isset($_COOKIE['lastVisit'])){
	$lastVisit=date('d-m-Y h:i:s',$_COOKIE['lastVisit']);
}//else{echo 'Cookie с именем lastVisit нету:)';}
if(date('d-m-Y',$_COOKIE['lastVisit']) != date('d-m-Y')){
setcookie('visitCounter',$visitCounter,time()+60*60*24*30,'/');
setcookie('lastVisit',time(),time()+60*60*24*30,'/');
}
/* 0x7FFFFFFF - время жизни в двоичной системе В десятичной системе это 2147483647
 Обозначает время 2038-01-19 06:14:07 */