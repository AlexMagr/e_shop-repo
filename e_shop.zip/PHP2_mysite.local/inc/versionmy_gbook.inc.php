<?php
session_start();

/* $ses_id=session_id();
var_dump($ses_id);
echo '<br>'; */
//session для предотвращения повторной записи в БД
/* <!-- Основные настройки --> */
define('DB_HOST','localhost');
define('DB_LOGIN','root');
define('DB_PASSWORD',"");
define('DB_NAME','gbook');
$link=mysqli_connect(DB_HOST,DB_LOGIN,DB_PASSWORD,DB_NAME);
mysqli_query($link,"SET NAMES 'utf-8'"); 
/* var_dump($link); */
echo '<br>';
?>
<!-- Основные настройки -->

<!-- Сохранение записи в БД -->
<?php
//вспом. переменная $token для предотвращения повторной записи в БД
$token = rand(1, 9999);
$output="";
if($_SERVER['REQUEST_METHOD']=='POST'){
	//echo 'Проверяем, все ли поля пришли и формат e-mail.';
	if(isset($_POST['name']) and !empty($_POST['name'])){$name=$_POST['name'];
		}else{ 
			echo'Заполните имя, пожалуйста.'.'<br>';
			$kontr='не заполнено';
		}
	if(isset($_POST['email']) and !empty($_POST['email'])){$email=$_POST['email'];
		}else{
			echo'Заполните e-mail, пожалуйста.'.'<br>';
			$kontr='не заполнено';
		}	
	/* пример формата вывода: if (empty($email)) {exit("<font color='#FF0066'>Задайте адрес электронной почты,пожалуйста.</font><br>");unset($email); }else*/
	if (!preg_match("/^[a-z0-9_-]{1,20}+(\.){0,2}+([a-z0-9_-]){0,5}@(([a-z0-9-]+\.)+(com|net|org|mil|"."edu|gov|arpa|info|biz|inc|name|[a-z]{2})|[0-9]{1,3}\.[0-9]{1,3}\.[0-"."9]{1,3}\.[0-9]{1,3})$/is",$email)){ echo "<font color='#FF0066'>Формат электронной почты не соответствует ожидаемому.Заполните e-mail заново.</font><br>";$kontr='не заполнено';}
	if(isset($_POST['msg']) and !empty($_POST['msg'])){$msg=(string)$_POST['msg'];
		}else{
			echo'Заполните сообщение, пожалуйста.'.'<br>';	
			$kontr='не заполнено';
		}	
	$output="$name ($email) : $msg";
	/* if($output) echo "<h3> Сообщение от: $output </h3>"; */
	

		/* var_dump($_SESSION['token']);
		echo '<br>';
		var_dump( $_POST['token']);
		echo '<br>'; */
	if(!$kontr){// $kontr блокирует отправку пустых полей в БД	
		//проверяем несанкционированную отправку в БД и формируем запрос 
		if($_POST['token'] != $_SESSION['token']){
			
			/* var_dump($_SESSION['token']);
			echo '<br>';
			echo $_POST['token'].'<br>'; */
			
			$_SESSION['token'] = $_POST['token']; 
			$sql="INSERT INTO msgs(name, email, msg) VALUES ('$name', '$email', '$msg')";
			$res=mysqli_query($link,$sql) or die(mysqli_error($link));
			unset ($_POST['name'],$_POST['email']);
		} else{
			//echo 'Предотвращаем повторную запись в БД'.'<br>';
			unset ($_POST['name'],$_POST['email']);// удаляем использованные значения полей, чтобы они снова не появились в форме
			}
	}	
}/* else echo "<h3> Данные не были переданы</h3>";	 */	
/* session_destroy(); ставить нельзя, т.к. удаляется инфа.в $_SESSION['token']	 */
?>
<!-- Сохранение записи в БД -->

<!-- Удаление записи из БД -->
<?php

if($_SERVER['REQUEST_METHOD']=='GET'){
	
	$del=abs((int)$_GET[del]);
	//var_dump($del);
	$sql="DELETE FROM msgs WHERE id=$del";
	$result=mysqli_query($link,$sql) or die(mysqli_error($link));
}

?>
<!-- Удаление записи из БД -->

<h3>Оставьте запись в нашей Гостевой книге</h3>

<form method="post" action="<?= $_SERVER['REQUEST_URI']?>">
Имя: <br /><input type="text" name="name" value="<?php if (isset($_POST['name'])) echo $_POST['name'];?>"/><br />
Email: <br /><input type="text" name="email" value="<?php if (isset($_POST['email'])) echo $_POST['email'];?>"/><br />
Сообщение: <br /><textarea name="msg" value="<?php if (isset($_POST['msg'])) echo $_POST['msg'];?>"></textarea><br />
<input  type="hidden" name="token" value="<?php echo $token; ?>"/><br />
<br />
<input type="submit" type="hidden" value="Отправить!" />
</form>
<!-- Вывод записей из БД -->
<?php
$sql='SELECT id, name, email, msg, UNIX_TIMESTAMP(datetime) as dt FROM msgs ORDER BY id DESC';
$result=mysqli_query($link,$sql) or die(mysqli_error($link));
mysqli_close($link);
$count=mysqli_num_rows($result);
echo"<p>Всего записей в гостевой книге: $count</p>";
echo"<table border=1 >";
	echo"<tr>";
		echo"<th align=\"center\">E-mail</th>";
		echo"<th align='center'>Написал автор</th>";
		echo"<th align='center'>Время</th>";
		echo"<th align='center'>Сообщение</th>";
	echo"</tr>";
while($row=mysqli_fetch_assoc($result)){
	echo"<tr>";
		echo'<td>','<a href=\"mailto:',$row[email],'\">',$row[email],'</a>','</td>';
		echo"<td>",$row[name],"</td>";
		echo"<td>",strftime('%d-%m-%Y %H:%M:%S',$row[dt]),"</td>";
		echo"<td>",$row[msg],"</td>";
		echo"<td>","<p align='left'>","<a href=\"http://localhost/mysite.local/index.php?id=gbook&del=",$row[id],"\"",">",'Удалить','</a>',"</p>","</td>";
		
		
		
	echo"</tr>";
}	
echo"</table>";	

?>
<!-- Вывод записей из БД -->
