<?
$dt=time();
$page=$_SERVER['REQUEST_URI'];//URI, который был предоставлен для доступа к этой странице. Например, '/index.html'.
$ref=$_SERVER['HTTP_REFERER'];//Адрес страницы (если есть), с которой браузер пользователя перешёл на эту страницу.
//для вытаскивания только конкретного имени файла без папок.
$ref=pathinfo($ref,PATHINFO_BASENAME);

$path="$dt|$page|$ref\n";
//или ещё один способ представления $path
//$path=serialize(['dt'=>$dt,'page'=>$page,'ref'=>$ref]);
//лог-файл сразу же создается на основе  информации в PATH_LOG
file_put_contents('log/'.PATH_LOG,$path , FILE_APPEND);
