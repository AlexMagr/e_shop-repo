<?php
	require "inc/lib.inc.php";
	require "inc/db.inc.php";
/* 	получение и обработка данных из формы */
	$n= clearStr($_POST['name']);
	$p= clearStr($_POST['phone']);
	$e= clearStr($_POST['email']);
	$a= clearStr($_POST['address']);
	/* получение идентификатора заказа */
	$oid=$basket['orderid'];
	/* получение временной метки заказа */
	$dt=time();
	$order="$n|$e|$p|$a|$oid|$dt\n";
	/* сохраняем значение $order в файле с именем из константы ORDERS_LOG,данные записываются в конец файла */
	file_put_contents('admin/'.ORDERS_LOG,$order,FILE_APPEND);
	/* после проверки удаляем 'admin/order.log', с тестовой информацией*/
	/* сохраняем данные о времени заказа в базе */
	saveOrder($dt);	
?>
<html>
<head>
	<title>Сохранение данных заказа</title>
</head>
<body>
	<p>Ваш заказ принят.</p>
	<p><a href="catalog.php">Вернуться в каталог товаров</a></p>
</body>
</html>