<?php
header("Content-Type:text/html;charset=utf-8");
define('DB_HOST','localhost');
define('DB_LOGIN','root');
define('DB_PASSWORD',"");
define('DB_NAME','eshop');
define('ORDERS_LOG','orders.log');//имя файла с личными данными пользователей

//Корзина покупателя
$basket=[];
//Количество товаров(позиций) покупателя
$count=0;
// У Борисова Соединение с сервером и Проверка подключения	
$link=mysqli_connect(DB_HOST,DB_LOGIN,DB_PASSWORD,DB_NAME) or die(mysqli_connect_error());

/* //Соединение с сервером мой вариант
$link=mysqli_connect(DB_HOST,DB_LOGIN,DB_PASSWORD,DB_NAME);
//Проверка подключения
if (!$link) {
    die('Ошибка подключения (' . mysqli_connect_errno() . ') '. mysqli_connect_error());
}else{
	mysqli_query($link,"SET NAMES 'utf-8'");
	echo 'Соединение установлено... ' . mysqli_get_host_info($link) . "\n";
	} */
basketInit();//сразу создаем корзину или вызываем уже существующую.



