<?php
/* функция фильтрации числовых данных формы */
function clearInt($data){
	return abs((int)($data));
}
/* функция фильтрации строковых данных формы */
function clearStr($data){
	global $link;// импортируем наш link
	return mysqli_real_escape_string($link,trim(strip_tags($data)));
}

/* функция добавления товара  в каталог */
function addItemToCatalog($title,$author,$pubyear,$price){
//подготовленный запрос
	global $link;
	$sql="INSERT INTO catalog(title,author,pubyear,price)
				VALUES(?,?,?,?)";
//исполнение подготовленного запроса			
	if(!$stmt=mysqli_prepare($link,$sql)) return false;
	mysqli_stmt_bind_param($stmt,"ssii",$title,$author,$pubyear,$price);
	mysqli_stmt_execute($stmt);
	mysqli_stmt_close($stmt);
	return true;
}	
/* 	функция выборки товара из каталога */
function selectAllitems(){
	global $link;
	$sql='SELECT id, title,author,pubyear,price
			FROM catalog';
	if(!$result=mysqli_query($link,$sql))
		return false;
	$items=mysqli_fetch_all($result,MYSQLI_ASSOC);	
	mysqli_free_result($result);// освобождаем память result
	return $items;
}
/* функция сохранения корзины с товарами в куки */
function saveBasket(){
	global $basket;
	$basket=base64_encode(serialize($basket));
	//base64_encode чтобы serialize правильно отработала в случае php версии 5 и ниже на апострофах и кавычках
	setcookie('basket',$basket,0x7FFFFFFF);
}
/* функция создает либо загружает в переменную $basket корзину с товарами, либо создает новую корзину с идентификатором заказа */
function basketInit(){
	global $basket, $count;
	if(!isset($_COOKIE['basket'])){
		$basket=array('orderid' => uniqid());
		saveBasket();
	}else{
		$basket=unserialize(base64_decode($_COOKIE['basket']));
		/* print_r($basket);exit; */
		$count=count($basket)-1;
	}
}
/* ф-я добавляет товар в корзину пользователя и принимает в качестве аргумента идентификатор товара   и его количество*/
function add2Basket($id,$q){
	global $basket;
	$basket[$id]=$q;// подсчитываем кол-во товара в штуках $basket[$id]+=$q; моя версия
	saveBasket();
}
/* ф-я возвращает всю пользовательскую корзину в виде ассоциативного массива */
function myBasket(){
	global $link,$basket;
	$goods=array_keys($basket);
	array_shift($goods);// убираем orderid
	/* Проверка наполненности корзины вар.А */
	if(!$goods)
		return array();
	$ids=implode(",",$goods);//склеиваем массив в строку
	/* Проверка наполненности корзины вар.Б 
	 if(count($goods))//условие для полной корзины
		$ids=implode(",",$goods);
	else
		$ids=0;//условие для пустой корзины */
	$sql="SELECT id,author,title,pubyear,price 
			FROM catalog
			WHERE id IN ($ids)";
	if(!$result=mysqli_query($link,$sql)) return false;	
	$items=result2Array($result);
	mysqli_free_result($result);
	return $items;
}
/* ф-я принимает рез-т в процессе выполнения myBasket() и возвращает ассоциативный массив товаров, дополненный их количеством */
function result2Array($data){
	global $basket;
	$arr=[];
	while($row=mysqli_fetch_assoc($data)){
		$row['quantity']=$basket[$row['id']];
		$arr[]=$row;
	}
	return $arr;
}
/* ф-я удаления товара из корзины,принимая в качестве аргумента его идентификатор */
function deleteItemFromBasket($id){
	global $basket;
	unset($basket[$id]);
	saveBasket();
}
/* ф-я добавления заказа в БД */
function saveOrder($dt){
	global $link,$basket;
	$goods=myBasket();//извлекаем корзину
	$stmt=mysqli_stmt_init($link);//будем работать с подготовленным запросом см.ниже. система ожидает дальнейшего использования  ...prepare
	$sql='INSERT INTO orders(title,author,pubyear,price,quantity,orderid,datetime)
					VALUES(?,?,?,?,?,?,?)';
	if(!mysqli_stmt_prepare($stmt,$sql))
		return false;
/* выбираем товары,используя параметры */
	foreach($goods as $item){
		mysqli_stmt_bind_param($stmt,"ssiiisi",$item['title'],$item['author'],$item['pubyear'],$item['price'],$item['quantity'],$basket['orderid'],$dt);
		mysqli_stmt_execute($stmt);
	}
	mysqli_stmt_close($stmt);
	setcookie('basket','',time()-3600);//удаляем куки пользователя
	return true;
}
/* ф-я возвращает многомерный массив с информацией о всех заказах, включая персональные данные покупателя и список его товаров */
function getOrders(){
	global $link;
	//проверяем существование файла оrders.log
	if(!is_file(ORDERS_LOG))
		return false;
	// получаем в виде массива персональные данные пользователя из файла
	$orders=file(ORDERS_LOG);
	//массив, который будет возвращен функцией
	$allorders=[];
	
	foreach($orders as $order){
		list($name,$email,$phone,$address,$orderid,$date)=explode("|",$order);
	//промежуточный массив для хранения информации о конкретном заказе
		$orderinfo=[];
	//сохраняем информацию о конкретном пользователе
		$orderinfo["name"]=$name;
		$orderinfo["email"]=$email;
		$orderinfo["phone"]=$phone;
		$orderinfo["address"]=$address;
		$orderinfo["orderid"]=$orderid;
		$orderinfo["date"]=$date;
	//SQL - запрос на выборку из таблицы orders всех товаров для конкретного покупателя
		$sql="SELECT title, author, pubyear, price, quantity 
				FROM orders
				WHERE orderid='$orderid' AND datetime=$date";
	//получение результата выборки
		if(!$result=mysqli_query($link,$sql))
			return false;
		$items=mysqli_fetch_all($result,MYSQLI_ASSOC);
		mysqli_free_result($result);
	//сохранение результата в элемент промежуточного массива
		$orderinfo["goods"]=$items;
	//добавление промежуточного массива в элемент возвращаемого массива
	$allorders[]=$orderinfo;	
	}
	return $allorders;
}