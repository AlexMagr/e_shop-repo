<?
define('FILE_NAME','.htpasswd');
/* ф-я генерирует хеш пароля($string), хотя в руководстве рнр не рекомендуют использовать sha1() для этого */
function getHash($string, $salt, $iterationCount){
	for($i=0;$i<$iterationCount;$i++)
		$string=sha1($string.$salt);
	return $string;
}
/* ф-я создает новую запись в файле пользователей */
function saveHash($user, $hash, $salt, $iteration){
	$str="$user:$hash:$salt:$iteration\n";
	if(file_put_contents(FILE_NAME, $str, FILE_APPEND))
		return true;
	else
		return false;
}
/* ф-я проверяет наличие пользователя в списке */
function userExists($login){
	if(!is_file(FILE_NAME))
		return false;
	$users=file(FILE_NAME);
	foreach($users as $user){
		if(strpos($user,$login)!==false)
			return $user;
	}
	return false;
}
/* ф-я завершает сеанс пользователя */
function logOut(){
	session_destroy();
	header('Location:secure/login.php');
	exit;
}