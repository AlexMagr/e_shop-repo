<?php
	
	if(!isset($_COOKIE['Result'])){
		
		if ($_SERVER["REQUEST_METHOD"] == "POST") {	
			
			$result=0;//Переменная для суммы ответов
			
			if(isset($_SESSION['test'])){
				//Зачитываем проверочные ответы из ini-файла в массив
				
				$answers = parse_ini_file("answers.ini");
				//Проходим по ответам и смотрим, есть ли среди них правильные совпадения по ключам
				foreach($_SESSION['test'] as $value){//Здесь $value является значением
					
					if(array_key_exists($value,$answers))//Здесь $value является ключом
					//Суммируем  ответы в том числе и правильные
					$result+=(int)$answers[$value];
					
				}
				
				
				// Очищаем данные сессии
				session_destroy();
				$_SESSION=[];
				
				
				//Сохраняем результат в куки
				setcookie("Result",$result);
				//header("Location: " . $_SERVER["PHP_SELF"]."?title=".$_POST['title']);
				
				ob_end_flush;
			}
		}
	};
?>

<table width="100%">
	<tr>
		<td align="left">
			<p>Ваш результат: <?= $result?> из 30</p>
		</td>
	</tr>
</table>

